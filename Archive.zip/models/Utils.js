// models/Utils.js
const mongoose = require('mongoose');

// Country Schema
const countrySchema = new mongoose.Schema({
  name: String,
  code: String,
  phone_code: String,
  is_active: Boolean
});
const Country = mongoose.model('Country', countrySchema);

// State Schema
const stateSchema = new mongoose.Schema({
  name: String,
  code: String,
  country: { type: mongoose.Schema.Types.ObjectId, ref: 'Country' },
  is_active: Boolean
});
const State = mongoose.model('State', stateSchema);

// City Schema
const citySchema = new mongoose.Schema({
  name: String,
  state: { type: mongoose.Schema.Types.ObjectId, ref: 'State' },
  country: { type: mongoose.Schema.Types.ObjectId, ref: 'Country' },
  is_active: Boolean
});
const City = mongoose.model('City', citySchema);

// Language Schema
const languageSchema = new mongoose.Schema({
  name: String,
  code: String,
  is_active: Boolean
});
const Language = mongoose.model('Language', languageSchema);

module.exports = {
  Country,
  State,
  City,
  Language
};