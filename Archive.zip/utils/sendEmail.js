const nodemailer = require('nodemailer');

const sendEmail = async (to, subject, text) => {
  const transporter = nodemailer.createTransport({
    host: 'smtp.office365.com', // ✅ Office365 SMTP
    port: 587,
    secure: false, // ❌ Don't use SSL — Office365 requires TLS on port 587
    auth: {
      user: process.env.EMAIL_USERNAME, // test@mrgiftsolutions.com
      pass: process.env.EMAIL_PASSWORD  // examplein@123
    },
    tls: {
      ciphers: 'SSLv3'
    }
  });

  const mailOptions = {
    from: `"Esycles" <${process.env.EMAIL_USERNAME}>`,
    to,
    subject,
    text
  };

  return transporter.sendMail(mailOptions);
};

module.exports = sendEmail;
